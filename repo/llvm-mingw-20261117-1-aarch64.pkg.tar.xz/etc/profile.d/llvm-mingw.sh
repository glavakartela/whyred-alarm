# Add the llvm-mingw cross toolchain to PATH (appended, so the system
# clang/gcc keep priority).
case ":$PATH:" in
	*:/opt/llvm-mingw/llvm-mingw-ucrt/bin:*) ;;
	*) PATH="${PATH:+$PATH:}/opt/llvm-mingw/llvm-mingw-ucrt/bin" ;;
esac
export PATH
